#include "Adafruit_ST7735_Macros.h"
#include "Adafruit_TFTShield18_Macros.h"
#include "Adafruit_TFTShield18_API.h"
#include "Adafruit_ST7735_API.h"

void setRedBar(uint8_t on);
void setBlueBar(uint8_t on);
void setGreenBar(uint8_t on);
void setYellowBar(uint8_t on);
void drawWIN(void);
void drawLOSE(void);