#include "Interface.h"
#include "Adafruit_ST7735_Macros.h"
#include "Adafruit_TFTShield18_Macros.h"
#include "Adafruit_TFTShield18_API.h"
#include "Adafruit_ST7735_API.h"

void setRedBar(uint8_t on){
  if(on){
    Display_drawRect(0, 0, Display_width()/2, Display_height()/2, ST7735_RED);
    Display_fillRect(0, 0, Display_width()/2, Display_height()/2, ST7735_RED);
  }else{
    Display_drawRect(0, 0, Display_width()/2, Display_height()/2, ST7735_WHITE);
    Display_fillRect(0, 0, Display_width()/2, Display_height()/2, ST7735_WHITE);    
  }
}

void setBlueBar(uint8_t on){
  if(on){
    Display_drawRect(Display_width()/2, 0, Display_width()/2, Display_height()/2, ST7735_BLUE);
    Display_fillRect(Display_width()/2, 0, Display_width()/2, Display_height()/2, ST7735_BLUE);
  }else{
    Display_drawRect(Display_width()/2, 0, Display_width()/2, Display_height()/2, ST7735_WHITE);
    Display_fillRect(Display_width()/2, 0, Display_width()/2, Display_height()/2, ST7735_WHITE);    
  }
}

void setGreenBar(uint8_t on){
  if(on){
    Display_drawRect(0, Display_height()/2, Display_width()/2, Display_height()/2, ST7735_GREEN);
    Display_fillRect(0, Display_height()/2, Display_width()/2, Display_height()/2, ST7735_GREEN);
  }else{
    Display_drawRect(0, Display_height()/2, Display_width()/2, Display_height()/2, ST7735_WHITE);
    Display_fillRect(0, Display_height()/2, Display_width()/2, Display_height()/2, ST7735_WHITE);    
  }
}

void setYellowBar(uint8_t on){
  if(on){
    Display_drawRect(Display_width()/2, Display_height()/2, Display_width()/2, Display_height()/2, ST7735_YELLOW);
    Display_fillRect(Display_width()/2, Display_height()/2, Display_width()/2, Display_height()/2, ST7735_YELLOW);
  }else{
    Display_drawRect(Display_width()/2, Display_height()/2, Display_width()/2, Display_height()/2, ST7735_WHITE);
    Display_fillRect(Display_width()/2, Display_height()/2, Display_width()/2, Display_height()/2, ST7735_WHITE);
  }
}

void drawWIN(void){
  Display_fillScreen(ST7735_WHITE);
  Display_setCursor(Display_width()/2, Display_height()/2);
  Display_setTextSize(1, 1);
  Display_setTextColor(ST7735_BLACK);
  Display_print("You Win!");
}

void drawLOSE(void){
  Display_fillScreen(ST7735_WHITE);
  Display_setCursor(Display_width()/2, Display_height()/2);
  Display_setTextSize(1, 1);
  Display_setTextColor(ST7735_BLACK);
  Display_print("You Lose =(");
}